library(flashpcaR)
library(tidyverse)


args <- commandArgs(trailingOnly = TRUE)
fn <- args[1]
prj <- args[2]

bn <- basename(fn)
npcs <- 10
f <- flashpca(fn, ndim = npcs)

projections <- f$projection %>%
    as_tibble(.name_repair = "unique") %>%
    set_names(str_c("pc", 1:npcs))

# add pcs to corresponding phenotype file
pheno_file <- str_replace(fn, ".pruned", "") %>%
    str_replace("filter", "pheno") %>%
    str_c(".pheno")

read_delim(pheno_file, delim = " ") %>%
    cbind(projections) %>%
    write_delim(
        pheno_file,
        col_names = TRUE
    )

f$vectors %>%
    as_tibble(.name_repair = "unique") %>%
    set_names(str_c("pc", 1:npcs)) %>%
    write_delim(
        path = file.path(prj, str_interp("data/pheno/${bn}.vectors")),
        col_names = TRUE
    )

f$projection %>%
    as_tibble() %>%
    set_names(str_c("pc", 1:npcs)) %>%
    write_delim(
        path = file.path(prj, str_interp("data/pheno/${bn}.projections")),
        col_names = TRUE
    )

ggsave(
    file.path(prj, str_interp("plots/${bn}.projection.pc1.pc2.pdf")),
    plot(
        f$projection[, 1:2],
        xlab = "pc1", ylab = "pc2", frame = FALSE
    )
)

ggsave(
    file.path(prj, str_interp("plots/${bn}vectors_pc1_pc2.pdf")),
    plot(
        f$vectors[, 1:2],
        xlab = "pc1", ylab = "pc2", frame = FALSE
    )
)
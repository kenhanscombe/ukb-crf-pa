# Write CHR_BP SNP list

library(tidyverse)
library(data.table)


models <- c("m1", "m2", "m3", "m4")

phenotypes <- c(
    "vo2max", "vo2max.m", "vo2max.f",
    "slope", "slope.m", "slope.f",
    "pa", "pa.m", "pa.f"
)

hardy <- map_df(
    list.files("out", pattern = "hardy", full.names = TRUE),
    ~ fread(., nThread = 4)
)

hardy_lookup <- hardy %>%
    pull(MIDP) %>%
    set_names(hardy$ID)


write_hwe_filt_results <- function(model, phenotype) {
    results_snps <- fread(
        str_interp("out/bolt.${model}.${phenotype}.bgen.snp.stats.gz"),
        select = c("SNP", "CHR", "BP", "ALLELE1", "ALLELE0", "A1FREQ", "BETA", "SE", "P_BOLT_LMM"),
        nThread = 4
    ) %>%
        mutate(CHR_BP = str_c(CHR, BP, sep = "_"))

    results_snps$P_HWE <- hardy_lookup[results_snps$SNP]
    results_snps %>%
        filter(P_HWE > 1e-50) %>%
        write_delim(str_interp("out/${model}.${phenotype}.munged"), delim = "\t")
}


cross2(models, phenotypes) %>%
    map(paste) %>%
    map(~ write_hwe_filt_results(.[1], .[2]))
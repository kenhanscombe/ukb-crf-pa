import click
import pandas as pd


@click.command()
@click.option('-k', '--keep-file', help='Keep file (sample IDs in column 1')
@click.option('-r', '--ref-fam', help='Reference fam')
@click.option('-o', '--out', default='data/filter/fam.diff',
              help='Output file name')
def famdiff(keep_file, ref_fam, out):
    """Samples to exclude

    Returns a file of samples not in a fam of samples to keep,
    but in the UKB ref genotyped fam
    """
    kf = pd.read_csv(keep_file, sep=r'\s+', header=None)
    rf = pd.read_csv(ref_fam, sep=r'\s+', header=None)

    a = set(rf.iloc[:, 0])
    b = set(kf.iloc[:, 0])
    d = list(a.difference(b))
    pd.DataFrame({'FID': d, 'IID': d}).to_csv(
        out, sep=' ', header=False, index=False)


if __name__ == '__main__':
    famdiff()

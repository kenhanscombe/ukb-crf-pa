suppressPackageStartupMessages(suppressWarnings(library(tidyverse)))
suppressPackageStartupMessages(suppressWarnings(library(broom)))
suppressPackageStartupMessages(suppressWarnings(library(modelr)))


args <- commandArgs(trailingOnly = TRUE)
pheno_file <- args[1]
model_file <- pheno_file %>%
    str_replace(".pheno$", ".modelfit") %>%
    str_replace("data/pheno", "out")

pheno <- str_replace(basename(pheno_file), ".pheno", "")
sex <- ifelse(endsWith(pheno, "m") | endsWith(pheno, "f"), "", "+ factor(sex)")

y <- case_when(
    startsWith(pheno, "pa") ~ "pa",
    startsWith(pheno, "vo2max") ~ "vo2max",
    startsWith(pheno, "slope") ~ "slope"
)

crf_covar <- ifelse(
    y %in% c("vo2max", "slope"),
    "+ trend + factor(category)",
    ""
)

df <- read_delim(pheno_file, delim = " ") %>%
    mutate(agesq = age**2)

# base model
f1 <- str_c(
    str_interp("${y} ~ age ${sex} + factor(array) + factor(centre) ${crf_covar}"),
    str_c("pc", seq(10), collapse = "+"),
    sep = "+"
)

f2 <- str_c(f1, "agesq", sep = "+")
f3 <- str_c(f2, "bmi", sep = "+")
f4 <- str_c(f3, "factor(smoking) + factor(alcohol)", sep = "+")

m1 <- lm(f1, data = df)
m2 <- lm(f2, data = df)
m3 <- lm(f3, data = df)
m4 <- lm(f4, data = df)

# add residuals
df %>%
    spread_residuals(m1, m2, m3, m4) %>%
    write_delim(
        pheno_file,
        col_names = TRUE
    )

# write model fit
map_df(list(m1, m2, m3, m4), glance) %>%
    mutate(model = c("m1", "m2", "m3", "m4")) %>%
    write_delim(
        model_file,
        col_names = TRUE
    )
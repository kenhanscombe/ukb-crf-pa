import click
import pandas as pd


@click.command()
@click.option('-f', '--file', type=click.Path(), help='Association output file.')
@click.option('-k', '--keep', type=click.Path(), help='Keep file.')
@click.option('-o', '--out', help='Output file.')
def make_ldsc_input(file, keep, out):
    """
    Prepare BOLT-LMM association output for ldsc munge_sumstats.py
    """
    df = pd.read_csv(file, sep='\t', header=0, usecols=[
        'SNP', 'ALLELE1', 'ALLELE0', 'A1FREQ', 'BETA', 'P_BOLT_LMM'])

    df = df.rename({'ALLELE1': 'A1',
                    'ALLELE0': 'A2',
                    'P_BOLT_LMM': 'P',
                    'A1FREQ': 'A1_FREQ'}, axis='columns')

    n = len(open(keep).readlines())
    df['N'] = n

    # Only --statsFile assoc stats at PLINK genotypes includes F_MISS
    # df['N'] = [round(n * (1 - m)) for m in df['F_MISS']]

    df = df[['SNP', 'A1', 'A2', 'N', 'P', 'BETA']]
    df.to_csv(out, sep=' ', index=False)


if __name__ == '__main__':
    make_ldsc_input()

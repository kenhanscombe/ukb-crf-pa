import click
import itertools
import subprocess


@click.command()
@click.option('--fusion-script', help='FUSION script')
@click.option('--fusion-ref', help='FUSION script')
@click.option('--fusion-ref-ld-chr', help='FUSION script')
@click.option('--phenotype', type=str,
              help='List of phenotypes')
@click.option('--studies-tissue', type=str,
              help='List of single studies tissues')
@click.option('--gtex-v7-tissue', type=str,
              help='List of gtex v7 tissues')
@click.option('--chromosome', type=str,
              help='List of chromosomes')
@click.option('--gwasn', type=str,
              help='List of GWAS sample sizes')
def twas_coloc(
        fusion_script, fusion_ref, fusion_ref_ld_chr,
        phenotype, studies_tissue, gtex_v7_tissue, chromosome, gwasn):
    """
    Run FUSION TWAS and colocalization for selected tissues in each
    phenotype, by chromosome.
    """

    for p, s, c in itertools.product(
            eval(phenotype),
            eval(studies_tissue) + eval(gtex_v7_tissue),
            eval(chromosome)):

        n = eval(gwasn)[p]

        if s in eval(studies_tissue):
            t = 'single-tissue-studies'
            pos = 'pos.paneln'
        elif s in eval(gtex_v7_tissue):
            t = 'gtex-v7'
            pos = 'P01.pos'

        cmd = f'''
            Rscript {fusion_script} \
            --sumstats out/{p}.m2.nonmiss.sumstats \
            --weights {fusion_ref}/{t}/{s}.{pos} \
            --weights_dir {fusion_ref}/{t} \
            --ref_ld_chr {fusion_ref_ld_chr} \
            --chr {c} \
            --coloc_P 1 \
            --GWASN {n} \
            --out out/fusion/{p}.m2.{s}.chr{c}.dat
            '''

        # subprocess.run(cmd, check=True)
        click.echo(cmd)


if __name__ == '__main__':
    twas_coloc()

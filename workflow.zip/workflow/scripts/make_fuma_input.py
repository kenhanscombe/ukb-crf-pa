import click
import pandas as pd


@click.command()
@click.option('-f', '--file', type=click.Path(), help='Association output file.')
@click.option('-k', '--keep', type=click.Path(), help='Keep file.')
@click.option('-o', '--out', help='Output file.')
def make_fuma_input(file, keep, out):
    """
    Prepare BOLT-LMM association output for upload to FUMA.
    """
    df = pd.read_csv(file, sep='\t', header=0, usecols=[
        'CHR', 'BP', 'SNP', 'P_BOLT_LMM', 'ALLELE1', 'ALLELE0', 'BETA', 'SE'])

    n = len(open(keep).readlines())
    df['N'] = n
    df.to_csv(out, sep=' ', index=False, compression='gzip')


if __name__ == '__main__':
    make_fuma_input()

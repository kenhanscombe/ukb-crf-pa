import click
import glob
import pandas as pd


@click.command()
@click.option('-b', '--bim', help='Keep bim')
@click.option('-o', '--out', default='data/filter/bim.diff',
              help='Output file name')
def bimdiff(bim, out):
    """Variants to exclude

        Returns a file of variants not in a bim of variants to keep,
        but in the UKB ref genotyped bim(s)
        """
    bim_files = glob.glob(
        '/scratch/datasets/ukbiobank/June2017/Genotypes/'
        'ukb_snp_chr[0-9]*_v2.bim.bz2')
    ref_bim = pd.concat([pd.read_csv(bf, sep='\t', header=None)
                         for bf in bim_files])
    usr_bim = pd.read_csv(bim, sep='\t', header=None)

    a = set(ref_bim.iloc[:, 1])
    b = set(usr_bim.iloc[:, 1])

    (pd.DataFrame(list(a.difference(b)))
     .to_csv(out, header=False, index=False))


if __name__ == '__main__':
    bimdiff()

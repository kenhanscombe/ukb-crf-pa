import click
import pandas as pd


@click.command()
@click.option('-f', '--fam', help='Keep file (sample IDs in column 1')
@click.option('-s', '--sample', help='Reference fam')
@click.option('-o', '--out', default='data/filter/fam.sample.diff',
              help='Output file name')
def famsamplediff(fam, sample, out):
    """Fam-sample difference

    Returns a file of samples in the fam file but not in the sample file
    """
    fam = pd.read_csv(fam, sep=r'\s+', header=None)
    sample = pd.read_csv(sample, sep=r'\s+', header=None, skiprows=2)

    a = set(fam.iloc[:, 0])
    b = set(sample.iloc[:, 0])
    d = list(a.difference(b))
    pd.DataFrame({'FID': d, 'IID': d}).to_csv(
        out, sep=' ', header=False, index=False)


if __name__ == '__main__':
    famsamplediff()
